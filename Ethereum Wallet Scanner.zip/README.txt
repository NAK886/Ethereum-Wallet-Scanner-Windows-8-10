Ethereum Waller Cracker v1.6



This project was made for research purposes


How it work?
=============
This tool generate a random ethereum address and check a balance, if found an alert is triggered.
You must create a free account on etherscan.io in order to have an API key.
From an old laptop from 2015 you can get 70/90 address checked per second.
Check our youtube video to know how it work.

EWS have only two options!
==========================
1 - "Generate one Ethereum Wallet"
This button will generate one ethereum address with his private key (run offline, no internet, no network, feel free to use it for security purpose)

2 - "CRACK"
This function will generate 20 ethereum wallets address and check their balance in bulk at a speed of 70/100 wallets per seconds if you have a good computer and internet connection.


TO-DO Before starting
=====================
You must register an account of Etherscan.io in order to get an API KEY
That will allow you to make 5 calls per seconds on their blockchain server.
Register and goto https://etherscan.io/myapikey  to generate your KEY.
Paste your API KEY in the file named " apikey-01.txt " save and close the file


Where is the file containing the found wallets?
================================================
All wallet with balance are added to the results.txt file inside the program directory.


Limitation / Full version?
==========================
This software is limited to scan/check 2000 address per day freely, if you want to unlock the tool you can send me the equivalent of $25 or 20€ in bitcoin/ethereum to the following address :

-= Bitcoin BTC address: bc1qst882e68t7ca475k0an3s95k67m7h0w6gge088
-= Ethereum ETH address: 0x1d90CB5716591f6e3fa102B9bCE8EEcC34bC2dC8
-= Stellar XLM address: GBIQS6W2KPWGX3YZ5PIBBSPSBMAYY522UGSVGRWYYH265QRSAN7KFFMU
-= Cardano ADA address: addr1q84wx5xjsuuqq9g928d6ycq20fxlxxnyjxess90tp8dr8qh2udgd9pecqq2s25wm5fsq57jd7vdxfydnpq27kzw6xwpq6frxzz

Send an email to " whitehatboy007@gmail.com " with your transaction link and DO NOT FORGET TO ADD YOUR ID code that you can find under the program menu ? --> About
I will send you back your registration code, simply enter this code in the text zone below the ID code to fully unlock the software.

Regards




History

Version 1.6 :	04/06/2021
Version 1.5 :	24/05/2021
Version 1.3 :	17/05/2021
Version 1.0 :	04/02/2021